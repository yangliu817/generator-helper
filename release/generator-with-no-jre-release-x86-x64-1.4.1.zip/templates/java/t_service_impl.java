[copyright]
[package]

[imports]

/**
 * @author [author]
 * @date [date]
 */
[annotations]
public class [className][extends][implements] {
    [logger]
    [fields]
[methods]
}
