[copyright]
[package]

[imports]

/**
 * @author [author]
 * @date [date]
 */
public interface [className][extends] {

[methods]
}
