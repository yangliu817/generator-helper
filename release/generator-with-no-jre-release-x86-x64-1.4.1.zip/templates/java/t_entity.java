[copyright]
[package]

import java.io.Serializable;
[imports]

/**
 * @author [author]
 * @date [date]
 * [comment]
 */
[annotations]
public class [className][extends] implements Serializable {

    private static final long serialVersionUID = 1L;

[constructor]

    [fields]

[setter-getter][equals-hash][toString]
}
