    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("[className] = {");

[if]
        sb.append("}");
        return sb.toString();
    }
