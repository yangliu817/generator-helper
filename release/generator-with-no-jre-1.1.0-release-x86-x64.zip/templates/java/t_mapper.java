[package]

[imports]
/**
 * @author [author]
 * @contact [contact]
 * @date [date]
 */
[annotations]
public interface [className][extends] {

[methods]
}
