        if ([fieldName] != null){
            sb.append("[fieldName] = ").append([fieldName]);
        }