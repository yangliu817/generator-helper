    public [className] set[fieldName-u]([fieldType] [fieldName]){
        this.[fieldName] = [fieldName];
        return this;
    }
