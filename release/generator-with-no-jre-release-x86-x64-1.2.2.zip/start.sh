cd jre

java -jar ../libs/generator-helper.jar