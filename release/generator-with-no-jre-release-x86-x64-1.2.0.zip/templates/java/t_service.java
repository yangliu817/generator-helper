[package]

[imports]

/**
 * @author [author]
 * @contact [contact]
 * @date [date]
 */
public interface [className][extends] {

[methods]
}
