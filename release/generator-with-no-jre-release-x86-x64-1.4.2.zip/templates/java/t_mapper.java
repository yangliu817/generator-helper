[copyright]
[package]

[imports]

/**
 * @author [author]
 * @date [date]
 */
[annotations]
public interface [className][extends] {

[methods]
}
