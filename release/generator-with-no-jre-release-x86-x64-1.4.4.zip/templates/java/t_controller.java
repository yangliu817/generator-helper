[copyright]
[package]

[imports]

/**
 * @author [author]
 * @date [date]
 */
[annotations]
public class [className] {
    [logger]
    [fields]

    [methods]

}
