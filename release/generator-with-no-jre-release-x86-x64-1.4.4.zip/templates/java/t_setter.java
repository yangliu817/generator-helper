    public void set[fieldName-u]([fieldType] [fieldName]){
        this.[fieldName] = [fieldName];
    }
