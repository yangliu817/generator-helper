    [comment]
    [annotations]
    private [fieldType] [fieldName];