[package]

[imports]

[annontations]
public class [className] {

    [fields]

    [methods]

}
