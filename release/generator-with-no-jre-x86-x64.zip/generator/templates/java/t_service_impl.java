[package]

[imports]

[annontations]
public class [className][extends][implements] {

    [fields]

}
