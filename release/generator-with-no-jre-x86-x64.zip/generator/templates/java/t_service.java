[package]

[imports]

public interface [className][extends] {

}
