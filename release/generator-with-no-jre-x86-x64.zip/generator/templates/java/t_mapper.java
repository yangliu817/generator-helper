[package]

[imports]

[annontations]
public interface [className][extends] {

}
