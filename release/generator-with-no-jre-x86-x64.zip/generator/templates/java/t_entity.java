[package]

import java.io.Serializable;
[imports]

/**
 * [comment]
 */
[annontations]
public class [className][extends] implements Serializable {

    private static final long serialVersionUID = 1L;

    [constructor]

    [fields]

    [setter-getter]

    [equals-hash]

    [toString]

}
