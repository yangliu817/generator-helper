[package]

import java.io.Serializable;
[imports]

/**
 * @author [author]
 * @contact [contact]
 * @date [date]
 * @desp [comment]
 */
[annotations]
public class [className][extends] implements Serializable {

    private static final long serialVersionUID = 1L;

[constructor]

    [fields]

[setter-getter][equals-hash][toString]
}
