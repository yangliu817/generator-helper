[package]

[imports]

/**
 * @author [author]
 * @contact [contact]
 * @date [date]
 */
[annotations]
public interface [className] extends JpaRepository<[entityClassName], [primaryKeyType]>, JpaSpecificationExecutor<[entityClassName]> {

}
