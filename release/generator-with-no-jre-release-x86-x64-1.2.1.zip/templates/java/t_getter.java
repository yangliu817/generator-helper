    public [returnType] get[fieldName-u](){
        return [fieldName];
    }
